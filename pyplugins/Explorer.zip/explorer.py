import os,time,sys,json
import importlib.util
import importlib
 
def dynamic_import(module):
    return importlib.import_module(module)
 
if not os.path.exists("config.json"):
    jsont = {
    "startDir": os.getcwd()
    }
    with open("config.json", "w", encoding="utf-8") as config:
        json.dump(jsont, config, indent = 4)
        
if not os.path.exists("launchpy.bat"):
    path = "python explorer.py"
    with open("launchpy.bat", "w", encoding="utf-8") as lp:
        lp.write(path)
mainpt = os.getcwd()
def update_pl(dirw):
    plugins = []
    for file in os.listdir(dirw+"\\plugins"):
        if os.path.isfile(dirw+"\\plugins\\"+file):
            plugins.append(dirw+"\\plugins\\"+file)
    return plugins
plugins = update_pl(mainpt)
def use_plugin(plugin, cmd, args):
    oldcwd = os.getcwd()
    try:
        dirn = os.path.dirname(plugin)
        os.chdir(dirn)
        p = os.path.basename(plugin)
        p = os.path.splitext(p)[0]
        m = dynamic_import(f'plugins.{p}')
    except Exception as e:
        p = os.path.basename(plugin)
        print(f"Ошибка в модуле: {p}" +"\nОшибка с плагином!\nВозможно, вы не указали главную функцию!")
        print(f"Имя ошибки: {str(e.__class__.__name__)}")
        print(f"Ошибка:{str(e)}")
    else:
        try:
            dirn = os.path.dirname(plugin)
            os.chdir(dirn)
            p = os.path.basename(plugin)
            p = os.path.splitext(p)[0]
            if not "data" in [item for item in dir(m) if not item.startswith("__")]:
                raise NameError("Не указана переменная data с данными!")
        except Exception as e:
            p = os.path.basename(plugin)
            print(f"Ошибка в модуле: {p}" +"\nОшибка с версией плагина! Укажите словарь data в начале файла плагина!")
            print(f"Имя ошибки: {str(e.__class__.__name__)}")
            print(f"Ошибка:{str(e)}")
        else:
            if True:
                d = False
                if args.split(" ") == [""]:
                    args = None
                try:
                    d = m.main(oldcwd, cmd, args)
                except Exception as e:
                    p = os.path.basename(plugin)
                    print(f"Ошибка в модуле: {p}" +"\nОшибка с функцией main!")
                    print(f"Имя ошибки: {str(e.__class__.__name__)}")
                    print(f"Ошибка:{str(e)}")
                else:
                    if d != False and d != True:
                        p = os.path.basename(plugin)
                        print(f"Ошибка в модуле: {p}" +"\nОшибка с функцией main, возврат функции не является boolean`ом!\nВозможно, вы не указали данные, чтобы возвращать!")
                    os.chdir(oldcwd)
                    return d
def list_plugin(plugins):
    print("Установленные плагины:")
    for plugin in plugins:
        p = None
        oldcwd = os.getcwd()
        if True:
            try:
                dirn = os.path.dirname(plugin)
                os.chdir(dirn)
                p = os.path.basename(plugin)
                p = os.path.splitext(p)[0]
                main = dynamic_import(f"plugins.{p}")
                data = main.data["plugin-data"]
            except Exception as e:
                p = os.path.basename(plugin)
                print(f"Ошибка в модуле: {p}" +"\nОшибка с версией плагина! Укажите словарь data в начале файла плагина!")
                print(f"Имя ошибки: {str(e.__class__.__name__)}")
                print(f"Ошибка:{str(e)}")
            else:
                if True:
                    os.chdir(oldcwd)
                    all1 = "Имя плагина:" + data["mname"] + "\n"
                    all1 += "Версия плагина: " + data["mversion"]
                    print(all1)
# Установка основного пути через config.json        
with open("config.json") as config:
    config = json.load(config)
    wd = config["startDir"]
    os.chdir(wd)

def start(args):
    if args.split(" ") == [""]:
        print("Не указан файл!")
    else:
        try:
            os.startfile(args)
        except Exception as e:
            print("Возникла ошибка!\n"+str(e.__class__.__name__)+":")
            print(str(e))

# Сообщение приветствия
print("\nEXPLORER v0.9 BETA - Explore your system!")
print("Введите 'help' для получения помощи.")

# Цикл написания команд
while True:
    us = input(f"EX {os.getcwd()}> ")
    cmd = us.split(' ')[0]
    args = " ".join(us.split(" ")[1:]) # аргументы
    # Длинный if проверки названия комманды. В этом случае - help
    if cmd == "help":
        helpar = ["Команды EXPLORER:",
            "help - Отображает этот текст. Укажите help>>'<имя-файла>' чтобы записать help в файл. Поддерживаются только .txt!",
            "dir <папка> - Выписывать список файлов/директорий в директории",
            "cd <папка> - Перемещаться по директориям. \"..\" чтобы выйти из директории.",
            "mkdir <папка> - Создавать директории",
            "rmdir <папка> - Уничтожать директории",
            "start <имя-файла>(Или путь к файлу) - Запустить файл"
        ]
        argss = args.split(">>")
        args = "".join(argss[1:])
        if args.startswith(" "):
            args = "".join(args.split(" ")[1:])
        if args != "":
            if os.path.exists(args):
                if os.path.isfile(args):
                    if args.endswith(".txt"):
                        with open(args, "w", encoding = "utf-8") as hf:
                            hf.write("\n".join(helpar))
                    else:
                        print("Файл не оканчивается на .txt!")
                else:
                    print("Путь является папкой!")
            else:
                print("Файл не существует!")
        else:
            for command in helpar:
                symc = 0
                for sym in command:
                    if symc == len(command)-1:
                        print(sym, end = "\n")
                    else:
                        print(sym, end = "")
                    symc+=1
                    time.sleep(0.0002)
    # непонятная тарабарщина записывания хелпа в файл
    elif cmd.startswith("help>>"):
        helpar = ["Команды EXPLORER:",
            "help - Отображает этот текст. Укажите help>>'<имя-файла>' чтобы записать help в файл. Поддерживаются только .txt!",
            "dir <папка> - Выписывать список файлов/директорий в директории",
            "cd <папка> - Перемещаться по директориям. \"..\" чтобы выйти из директории.",
            "mkdir <папка> - Создавать директории",
            "rmdir <папка> - Уничтожать директории",
            "read <имя файла>(Или путь к файлу) - Прочитать файл и вывести данные",
            "start <имя-файла>(Или путь к файлу) - Запустить файл или программу",
            "exit - выход"
            ]
        argso = args
        args = "".join(cmd.split(">>")[1:])
        if args != "":
            argss = args.split(" ")
            if True:
                if args != "":
                    if os.path.exists(args):
                        if os.path.isfile(args):
                            if args.endswith(".txt"):
                                with open(args, "w", encoding = "utf-8") as hf:
                                    hf.write("\n".join(helpar))
                            else:
                                print("Файл не оканчивается на .txt!")
                        else:
                            print("Путь является папкой!")
                    else:
                        print("Файл не существует!")
                else:
                    print("Не указан файл!")
        else:
            args = argso
            if args != "":
                argss = args.split(" ")
                if True:
                    if args != "":
                        if os.path.exists(args):
                            if os.path.isfile(args):
                                if args.endswith(".txt"):
                                    with open(args, "w", encoding = "utf-8") as hf:
                                        hf.write("\n".join(helpar))
                                else:
                                    print("Файл не оканчивается на .txt!")
                            else:
                                print("Путь является папкой!")
                        else:
                            print("Файл не существует!")
                    else:
                        print("Не указан файл!")
    elif cmd == "dir":
        if args.split(" ") == [""]:
            dirc = os.getcwd()
        else:
            dirc = args
            if os.path.exists(dirc):
                dirc = args
            else:
                print("Несуществующая директория!")
                dirc = os.getcwd()
        print(f"Анализ директории {dirc}:")
        dirs = []; files = []
        for el in os.listdir(dirc):
            if os.path.isdir(el):
                dirs.append(f"Директория: {el} -  Последнее изменение: {time.ctime(os.path.getmtime(el))} - Дата создания: {time.ctime(os.path.getctime(el))}")
            if os.path.isfile(el):
                statinfo = os.stat(el)
                stat = str(statinfo.st_size).replace("L", "B")
                files.append(f"Файл: {el} - Размер:{stat}B - Последнее изменение: {time.ctime(os.path.getmtime(el))} - Дата создания: {time.ctime(os.path.getctime(el))}")
        for dir1 in dirs:
            print(dir1)
        for file in files:
            print(file)
    elif cmd == "cd":
        if args.split(" ") == [""]:
            dirc = os.getcwd()
            print("Несуществующая директория!")
        else:
            dirc = args
            if os.path.exists(dirc):
                args = args.replace("/","\\")
                dirc = args
            else:
                args = args.replace("/","\\")
                dirc = os.getcwd()+"\\"+args
                if not os.path.exists(dirc):
                    print("Несуществующая директория!")
        os.chdir(dirc)
    elif cmd == "mkdir":
        if args.split(" ") == [""]:
            print("Не указана директория!")
        else:
            args = args.replace("/","\\")
            direc = args
            if os.path.exists(direc):
                if os.path.isdir(direc):
                    print("Папка уже существует!")
                else:
                    os.mkdir(direc)
                    print("Папка успешно создана!")
            else:
                os.mkdir(direc)
    elif cmd == "rmdir":
        if args.split(" ") == [""]:
            print("Несуществующая директория!")
        else:
            args = args.replace("/","\\")
            direc = args
            if os.path.exists(direc):
                if os.path.isdir(direc):
                    if os.listdir(direc):
                        print("В папке есть файлы!")
                    else:
                        os.rmdir(direc)
                else:
                    print("Несуществующая директория!")
            else:
                print("Несуществующая директория!")
    elif cmd == "read":
        with open(args, encoding="utf-8") as rf:
            data = rf.read()
        for el in data.split("\n"):
            print(el)
    elif cmd == "exit":
        print("Выходим из программы...")
        break
    elif cmd == "fe":
        if args.split(" ") == [""]:
            print("Не указан файл!")
        else:
            fe = True
            print("FileEditor v0.5")
            lines = []
            while fe:
                line = len(lines) 
    elif cmd == "start":
        start(args)
    elif cmd == "lp":
        plugins = update_pl(mainpt)
        list_plugin(plugins)
    else:
        y = 0
        for plugin in plugins:
            plugins = update_pl(mainpt)
            d = use_plugin(plugin, cmd, args)
            if d == True:
                y += 1
        if y == 0:
            print("Неизвестная команда!")