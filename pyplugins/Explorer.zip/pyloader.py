import aiohttp, asyncio, zipfile, os, platform
loop = asyncio.get_event_loop()

url = 'https://www.python.org/ftp/python/3.8.2/python-3.8.2-embed-amd64.zip' #  http://gitfiddle.herokuapp.com/
async def download(url, filename):
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as resp:
            chunk_size = 1024
            chunks_all = 0
            with open(filename, 'wb') as fd:
                while True:
                    chunk = await resp.content.read(chunk_size)
                    if not chunk:
                        break
                    fd.write(chunk)
                    chunks_all += 1024
print("Downloading Python...")
loop.run_until_complete(download(url,'.\\python382.zip'))
print("Unpacking ZIP")
if not os.path.exists("python3.8.2"):
    os.mkdir("python3.8.2")
z = zipfile.ZipFile('python382.zip', 'r')
z.extractall(path = 'python3.8.2')
z.close()
while True:
    try:
        os.remove("python382.zip")
    except Exception as e:
        pass
    else:
        break
print("Success!")
print("Downloading explorer!")
loop.run_until_complete(download("",'.\\python382.zip'))
system = platform.system()
if system in ["Darwin","Linux"]:
    with open("launchpy.sh","w") as f:
        f.write("python3.8.2\\python.exe .\\explorer.py")
    os.startfile("launchpy.sh")
if system == "Windows":
    with open("launchpy.bat","w") as f:
        f.write("python3.8.2\\python.exe .\\explorer.py")
    os.startfile("launchpy.bat")