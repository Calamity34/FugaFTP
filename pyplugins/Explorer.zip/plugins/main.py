import os
data = {
    "plugin-data":
    {
        "mversion":"v1",
        "mname":"Python Code Interpretator(Only Base Libraries + Default Syntax)"
    }
}
def main(cwd = os.getcwd(),cmd = None,args = None, d = False):
    if cmd == "python":
        if args.split(" ") == [""] or args == None:
            print("Не указан файл!")
        else:
            if args.endswith(".py"):
                os.chdir(cwd)
                if os.path.exists(args):
                    print("Try")
                    exec(open(args).read())
                    print("Гыг")
            else:
                print("Файл не оканчивается на .py!")
        return True
    else:
        return False
