data = {
    "plugin-data":
    {
        "mversion":"v1",
        "mname":"Request Test"
    }
}
def main(cwd=None,cmd = None,args = None):
    if cmd == "None":
        print("Success!")
        return True
    return False
